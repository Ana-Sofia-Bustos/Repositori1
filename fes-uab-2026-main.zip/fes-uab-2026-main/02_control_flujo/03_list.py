###
# 03 - Listas
# Secuencias mutables de elementos.
# Pueden contener elementos de diferentes tipos.
###

import os
os.system("cls")

# Creación de listas
# print("\nCrear listas")
lista1 = [1, 2, 3, 4, 5] # lista de enteros
lista2 = ["manzanas", "peras", "plátanos"] # lista de cadenas
lista3 = [1, "hola", 3.14, True] # lista de tipos mixtos

lista_vacia = []
lista_de_listas = [[1, 2], ['calcetin', 4]]
#       1   [0][0]    2 [0][1]
# 'calcetin'[1][0]    4 [1][1]
# print(lista_de_listas[1][0]) # calcetin
matrix = [[1, 2], [2, 3], [4, 5]]

# print(lista1)
# print(lista2)
# print(lista3)
# print(lista_vacia)
# print(lista_de_listas)
# print(matrix)

# Acceso a elementos por índice
# print("\nAcceso a elementos por índice")
lista2 = ["manzanas", "peras", "plátanos", "fresas"]
print(lista2[0])  # manzanas
print(lista2[1])  # peras
print(lista2[-1]) # fresas
print(lista2[-2]) # plátanos

# print(lista_de_listas[1][0])

# Slicing (rebanado) de listas
lista1 = [1, 2, 3, 4, 5]
# print(lista1[1:4]) # [2, 3, 4]
# print(lista1[:3]) # [1, 2, 3]
# print(lista1[3:]) # [4, 5]
# print(lista1[:]) # [1, 2, 3, 4, 5] Copia de la lista


# HAY MÁS MAGIA
lista1 = [1, 2, 3, 4, 5, 6, 7, 8]
print(lista1[1:6:2]) # [2, 4, 6] # [inicio:fin:paso]
print(lista1[::2]) # para devolver índices pares
print(lista1[::-1]) # para devolver índices inversos

# Modificar una lista
lista1[0] = 20
print(lista1)
# Cuidado si no existe el índice, por ejemplo:
# lista1[10] = 100 # Error
# porque python no permite añadir elementos a una lista por índice

# Añadir elementos a una lista
lista1 = [1, 2, 3]

# forma larga y menos eficiente
lista1 = lista1 + [4, 5, 6]
print(lista1)

# forma corta y más eficiente
lista1 += [7, 8, 9]
print(lista1)

# Recuperar longitud de una lista
print("Longitud de la lista", len(lista1))

# En JavaScript, la longitud de un array se obtiene con .lenght

###
# EJERCICOS
###

# Ejercicio 1: El mensaje secreto
# Dada la siguiente lista:
# mensaje = ["C", "o", "d", "i", "g", "o", " ", "s", "e", "c", "r", "e", "t", "o"]
# Utilizando slicing y concatenación, crea una nueva lista que contenga solo el mensaje "secreto".
mensaje = ["C", "o", "d", "i", "g", "o", " ", "s", "e", "c", "r", "e", "t", "o"]
#numero : dins dels claudàtors d'una llista (per exemple, llista[2:]) és una operació coneguda com a slicing i vol dir "agafa tots els elements començant des de la posició 2 fins al final de la llista".
secreto = mensaje[7:]
print (secreto)

# Ejercicio 2: Intercambio de posiciones
# Dada la siguiente lista:
# numeros = [10, 20, 30, 40, 50]
# Intercambia la primera y la última posición utilizando solo asignación por índice.
numeros = [10, 20, 30, 40, 50]
numeros[0], numeros[4] = numeros[4] , numeros[0]
print (numeros)


# Ejercicio 3: El sándwich de listas
# Dadas las siguientes listas:
# pan = ["pan arriba"]
# ingredientes = ["jamón", "queso", "tomate"]
# pan_abajo = ["pan abajo"]
# Crea una lista llamada sandwich que contenga el pan de arriba, los ingredientes y el pan de abajo, en ese orden.
pan = ["pan arriba"]
ingredientes = ["jamón", "queso", "tomate"]
pan_abajo = ["pan abajo"]
sandwich= [pan,ingredientes,pan_abajo]
print (sandwich)

# Ejercicio 4: Duplicando la lista
# Dada una lista:
# lista = [1, 2, 3]
# Crea una nueva lista que contenga los elementos de la lista original duplicados.
# Ejemplo: [1, 2, 3] -> [1, 2, 3, 1, 2, 3]
lista = [1, 2, 3]
lista2= lista+ lista


# Ejercicio 5: Extrayendo el centro
# Dada una lista con un número impar de elementos, extrae el elemento que se encuentra en el centro de la lista utilizando slicing.
# Ejemplo: lista = [10, 20, 30, 40, 50] -> El centro es 30

# Ejercicio 6: Reversa parcial
# Dada una lista, invierte solo la primera mitad de la lista (utilizando slicing y concatenación).
# Ejemplo: lista = [1, 2, 3, 4, 5, 6] -> Resultado: [3, 2, 1, 4, 5, 6]