###
# EJERCICOS
###

# Ejercicio 1: El mensaje secreto
# Dada la siguiente lista:
# mensaje = ["C", "o", "d", "i", "g", "o", " ", "s", "e", "c", "r", "e", "t", "o"]
# Utilizando slicing y concatenación, crea una nueva lista que contenga solo el mensaje "secreto".
mensaje = ["C", "o", "d", "i", "g", "o", " ", "s", "e", "c", "r", "e", "t", "o"]
#numero : dins dels claudàtors d'una llista (per exemple, llista[2:]) és una operació coneguda com a slicing i vol dir "agafa tots els elements començant des de la posició 2 fins al final de la llista".
secreto = mensaje[7:]
print (secreto)

# Ejercicio 2: Intercambio de posiciones
# Dada la siguiente lista:
# numeros = [10, 20, 30, 40, 50]
# Intercambia la primera y la última posición utilizando solo asignación por índice.
numeros = [10, 20, 30, 40, 50]
numeros[0], numeros[4] = numeros[4] , numeros[0]
print (numeros)


# Ejercicio 3: El sándwich de listas
# Dadas las siguientes listas:
# pan = ["pan arriba"]
# ingredientes = ["jamón", "queso", "tomate"]
# pan_abajo = ["pan abajo"]
# Crea una lista llamada sandwich que contenga el pan de arriba, los ingredientes y el pan de abajo, en ese orden.
pan = ["pan arriba"]
ingredientes = ["jamón", "queso", "tomate"]
pan_abajo = ["pan abajo"]
sandwich= [pan,ingredientes,pan_abajo]
print (sandwich)

# Ejercicio 4: Duplicando la lista
# Dada una lista:
# lista = [1, 2, 3]
# Crea una nueva lista que contenga los elementos de la lista original duplicados.
# Ejemplo: [1, 2, 3] -> [1, 2, 3, 1, 2, 3]
lista1 = [1, 2, 3]
lista2= lista1+ lista1


# Ejercicio 5: Extrayendo el centro
# Dada una lista con un número impar de elementos, extrae el elemento que se encuentra en el centro de la lista utilizando slicing.
# Ejemplo: 
lista2 = [10, 20, 30, 40, 50]
lista30= lista2.pop (2)
print (lista30)
print(lista2)

# Ejercicio 6: Reversa parcial
# Dada una lista, invierte solo la primera mitad de la lista (utilizando slicing y concatenación).
#([::-1]) o el mètode .reverse().
# Ejemplo: 
lista3 = [1, 2, 3, 4, 5, 6]  #-> Resultado: [3, 2, 1, 4, 5, 6]
lista3[0:3] = lista3[0:3][::-1]
print (lista3)

